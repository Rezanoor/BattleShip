*Developed using VS 2019
*Simply open in VS, clean, build solution, and run unittest project
