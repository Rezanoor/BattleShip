﻿using BattleShip.lib.Model;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace BattleShip.Test
{
    public class InvalidFleetCozExceededTest
    {
        Game _game;

        public InvalidFleetCozExceededTest()
        {
            _game = new Game(10, 10);
        }

        [Fact]
        public void TestIsGameCreated()
        {
            Assert.NotNull(_game);
        }

        [Theory]
        [InlineData(1, 9)]
        public void SimpleTest(int x, int y)
        {
            //Create board
            Assert.NotNull(_game);

            //Add Fleet
            Squar squar1 = new Squar { x = 1, y = 1 };
            Squar squar2 = new Squar { x = 1, y = 2 };
            Squar squar3 = new Squar { x = 1, y = 10 };
            BattleFleet battleFleet = new BattleFleet { fleet = new Squar[] { squar1, squar2, squar3 }, type = FleetType.ship };
            //Should return false(Invalid Fleet)
            Assert.False(_game.AddFleet(battleFleet));

        }
    }
}
