﻿using BattleShip.lib.Model;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace BattleShip.Test
{
    public class IsFleetAtomicTest
    {

        Game _game;

        public IsFleetAtomicTest()
        {
            _game = new Game(10, 10);
        }


        [Fact]
        public void RunTest()
        {

            //Add Fleet
            Squar squarA1 = new Squar { x = 1, y = 1 };
            Squar squarA2 = new Squar { x = 1, y = 2 };
            Squar squarA3 = new Squar { x = 1, y = 3 };
            BattleFleet battleFleet1 = new BattleFleet { fleet = new Squar[] { squarA1, squarA2, squarA3 }, type = FleetType.ship };
            Assert.True(_game.TestFleetIsAtomic(battleFleet1), "Valid Fleet");

            //Add Fleet
            Squar squarB1 = new Squar { x = 1, y = 1 };
            Squar squarB2 = new Squar { x = 4, y = 2 };
            Squar squarB3 = new Squar { x = 1, y = 3 };
            BattleFleet battleFleet2 = new BattleFleet { fleet = new Squar[] { squarB1, squarB2, squarB3 }, type = FleetType.ship };
            Assert.False(_game.TestFleetIsAtomic(battleFleet2), "Invalid Fleet");

            //Add Fleet
            Squar squarC1 = new Squar { x = 9, y = 9 };
            Squar squarC2 = new Squar { x = 9, y = 1 };
            Squar squarC3 = new Squar { x = 9, y = 8 };
            BattleFleet battleFleet3 = new BattleFleet { fleet = new Squar[] { squarC1, squarC2, squarC3 }, type = FleetType.ship };
            Assert.False(_game.TestFleetIsAtomic(battleFleet3), "Invalid Fleet");


            //Add Fleet
            Squar squarD1 = new Squar { x = 2, y = 9 };
            Squar squarD2 = new Squar { x = 2, y = 0 };
            BattleFleet battleFleet4 = new BattleFleet { fleet = new Squar[] { squarB1, squarB2 }, type = FleetType.ship };

            Assert.False(_game.TestFleetIsAtomic(battleFleet4), "Invalid Fleet. Fleet is crossed");

        }
    }
}
