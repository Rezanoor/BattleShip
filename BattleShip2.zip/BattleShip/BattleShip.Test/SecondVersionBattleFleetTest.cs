﻿using BattleShip.lib.Model;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace BattleShip.Test
{
    public class SecondVersionBattleFleetTest
    {
        Game _game;

        public SecondVersionBattleFleetTest()
        {
            _game = new Game(10, 10);
        }


        [Fact]
        public void RunTest()
        {

            //Add Fleet
            Squar squarA1 = new Squar { x = 1, y = 1 };
            
            BattleFleet2 battleFleet1 = new BattleFleet2 { startPosition = squarA1 , length = 5,  direction = Direction.down,type = FleetType.ship };
            Assert.True(_game.AddFleet(battleFleet1));

            Squar squarB1 = new Squar { x = 5, y = 4 };

            BattleFleet2 battleFleet2 = new BattleFleet2 { startPosition = squarB1, length = 6, direction = Direction.right, type = FleetType.ship };
            Assert.False(_game.AddFleet(battleFleet2));


            BattleFleet2 battleFleet3 = new BattleFleet2 { startPosition = squarB1, length = 6, direction = Direction.down, type = FleetType.ship };
            Assert.True(_game.AddFleet(battleFleet3));
        }
    }
}
