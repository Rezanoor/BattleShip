﻿using BattleShip.lib.Model;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace BattleShip.Test
{
    public class MultipleAttackTest
    {
        Game _game;

        public MultipleAttackTest()
        {
            _game = new Game(10, 10);
        }

        [Fact]
        public void TestIsGameCreated()
        {
            Assert.NotNull(_game);
        }

        [Fact]
        public void RunTest()
        {
            //Create board
            Assert.NotNull(_game);

            //Add Fleet
            Squar squarA1 = new Squar { x = 1, y = 1 };
            Squar squarA2 = new Squar { x = 1, y = 2 };
            Squar squarA3 = new Squar { x = 1, y = 3 };
            BattleFleet battleFleet1 = new BattleFleet { fleet = new Squar[] { squarA1, squarA2, squarA3 }, type = FleetType.ship };
            Assert.True(_game.AddFleet(battleFleet1));

            //Add Fleet
            Squar squarB1 = new Squar { x = 2, y = 3 };
            Squar squarB2 = new Squar { x = 2, y = 4 };
            Squar squarB3 = new Squar { x = 2, y = 5 };
            Squar squarB4 = new Squar { x = 2, y = 6 };
            BattleFleet battleFleet2 = new BattleFleet { fleet = new Squar[] { squarB1, squarB2, squarB3, squarB4 }, type = FleetType.ship };
            Assert.True(_game.AddFleet(battleFleet2));

            //Attach
            Assert.Equal(_game.Attack(2, 3), 1);

            Assert.Equal(_game.Attack(2, 4), 1);

            Assert.Equal(_game.Attack(2, 5), 1);

            Assert.Equal(_game.Attack(3, 3), 0);


            //Has player lost
            Assert.False(_game.HasPlayerLostYet());
        }
    }
}
