﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.lib.Utility
{
    public class ArrayUtility
    {
        /// <summary>
        /// This method searches 2D array, and return the FIRST NONE zero value it finds
        /// </summary>
        /// <param name="array"></param>
        /// <returns></returns>
        public static int Find2DArray(int[,] array)
        {
            if (array == null) { 
                return 0; 
            }
            for (int col = 0; col < array.GetLength(0); col++)
            {
                for (int row = 0; row < array.GetLength(1); row++)
                {
                    if (array[col, row] != 0)
                    {
                        return array[col, row];
                    }
                } 
            }
            return 0;
        }
    }
}
