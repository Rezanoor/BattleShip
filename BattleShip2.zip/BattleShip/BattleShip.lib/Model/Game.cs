﻿using BattleShip.lib.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.lib.Model
{
    /// <summary>
    /// Game is the main class. It has two properties. 
    /// board which is a two dimensional array with given length, and width.
    /// battleFleets stores the fleet on the board. Each fleet contains an array of squars with position propertis(x,y), and the fleet type. 
    /// Sample of a Fleet: Fleet = {[{1,2,flase},{1,3,flase},{1,4,false}], 1}
    /// ***NOTE***
    /// 1- There are two addFleet methods are designed. They accept two different version of fleet. Each of them has pros and cons
    /// 2- The battleFleets property may not be very necessary. Just for reporting matters in the future. Please note the battleFleets
    /// property only work with the first verion of Fleet. 
    /// The attack method actually manipulates this property to keep track of fleets state. This is where the disadvantage of second version
    /// can be explained because it is not possible/easy to keep track of fleet state(how much destroyed, and how much left) in the second version.
    /// The advantage of second version of fleet is we don't really need to do a lot of validation on the fleet like we do for the first version
    /// </summary>
    public class Game
    {
        #region properties
        int[,] board { get; set; }
        List<BattleFleet> battleFleets { get; set; }
        #endregion properties

        #region constructor
        public Game(int length, int width)
        {
            board = new int[length, width];
            battleFleets = new List<BattleFleet>();
        }
        #endregion constructor

        #region public methods
        /// <summary>
        /// Add fleet to the game
        /// 1- Validate the fleet
        /// 2- Add it to the board by simply setting the board squar matching with the fleet to the fleet type number
        /// 3- Add it to the fleet list
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns>If successful(validation and add) return true else return false</returns>
        public bool AddFleet(BattleFleet battleFleet)
        {
            //Validate fleet
            if (board != null && battleFleets != null && IsFleetValid(battleFleet))
            {
                //Add to the baord, loop through the fleet square,and set the board room to the fleet type number
                Array.ForEach(battleFleet.fleet, squar => board[squar.x, squar.y] = (int)battleFleet.type);
                //Add to the fleet list
                battleFleets.Add(battleFleet);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This is the **SECOND** version of AddFleet accepts the second version of battleFleet class(BattleFleet2)
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns></returns>
        public bool AddFleet(BattleFleet2 battleFleet)
        {
            //Validate fleet
            if (board != null && battleFleets != null && DoesFleetFit(battleFleet))
            {
                if (battleFleet.direction.Equals(Direction.right))
                {
                    for(int i = 0; i < battleFleet.length; i++)
                    {
                        board[battleFleet.startPosition.x, battleFleet.startPosition.y + i] = (int) battleFleet.type;
                    }
                } 
                else
                {
                    for (int i = 0; i < battleFleet.length; i++)
                    {
                        board[battleFleet.startPosition.x + 1, battleFleet.startPosition.y] = (int)battleFleet.type;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 1- Get the board room which attach is targetted
        /// 2- If attack is NOT missed, Set the destroyed property of the fleet square to true if found
        /// 3- If attack is NOT missed, zerorise the board room attack is done
        /// 4- Return the Fleet number type if attack is successful, if not return 0
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns>
        /// Return 0 if attack is a miss, greater than zero attack is successful and the number is the number of fleet type (e.g 1,2,3)
        /// </returns>
        public int Attack(int x, int y)
        {
            //Get the board room which attach is targetted
            int value = board[x, y];
            //If attack is NOT missed
            if (value != 0)
            {
                //Set the destroyed property of the fleet square to true if found
                DestroyFleetSquar(x, y);
                //zerorise the board room attack is done, this will help tracking if user has lost yet
                board[x, y] = 0;
            }
            //Return the Fleet number type if attack is successful, if not return 0
            return value;
        }

        /// <summary>
        /// Loop through the board, and check if there is any room with a none zero value,
        /// if there is, user hasn't lost yet
        /// </summary>
        /// <returns>
        /// true if player has lost(all rooms zero), 
        /// false if not(there are still room with none zero value)
        /// </returns>
        public bool HasPlayerLostYet()
        {
            return ArrayUtility.Find2DArray(board) == 0;
        }

        /// <summary>
        /// This piblic method is used only for unit testing
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns>
        /// true if validation successful, false if not
        /// </returns>
        public bool TestFleetIsAtomic(BattleFleet battleFleet)
        {
            return FleetIsAtomic(battleFleet);
        }

        #endregion public methods

        #region private methods
        /// <summary>
        /// Set destroyed property for the Battle Fleet to true if found
        /// Search the battle fleet list and check if there is match with the given position
        /// This method is designed to get a report on the list of fleet have been hit, and etc
        /// </summary>
        private void DestroyFleetSquar(int x, int y)
        {
            if (battleFleets != null && battleFleets.Count > 0)
            {
                battleFleets.ForEach(battleFleet => {
                    Squar fleetSquar = Array.Find(battleFleet.fleet, fs => fs.x == x && fs.y == y);
                    if (fleetSquar != null)
                    {
                        fleetSquar.destroyed = true;
                    }
                });
            }
        }

        /// <summary>
        /// Validate fleet
        /// 1- Check if the size of the fleet exceed the panel
        /// 2- Check the fleet is only vertical or horizontal (no cross)
        /// 3- Check if the fleet is atomic (All squares of the fleet are next to each other)
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns>
        /// true if validation successful, false if not
        /// </returns>
        private bool IsFleetValid(BattleFleet battleFleet)
        {
            return battleFleet != null && 
                FleetHasNotExceededPanel(battleFleet) && 
                FleetHasNotCrossed(battleFleet) &&
                FleetIsAtomic(battleFleet);
        }

        /// <summary>
        /// Check if the lenght of Fleet doesn't exceed in second version of Fleet
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns></returns>
        private bool DoesFleetFit(BattleFleet2 battleFleet)
        {
            if (battleFleet.direction.Equals(Direction.right) && battleFleet.length + battleFleet.startPosition.x > board.GetLength(0))
            {
                return false;
            }
            if(battleFleet.direction.Equals(Direction.down) && battleFleet.length + battleFleet.startPosition.y > board.GetLength(1))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check if the size of the fleet exceed the panel
        /// Example of exceeded fleet:
        /// [][][]
        /// [][*][*]*
        /// [][][]
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns>true if validation successful, false if not</returns>
        private bool FleetHasNotExceededPanel(BattleFleet battleFleet)
        {
            return Array.Find(battleFleet.fleet, fleet => fleet.x > board.GetLength(0) || fleet.y > board.GetLength(1)) == null;
        }

        /// <summary>
        /// Check the fleet is only vertical or horizontal (no cross)
        /// Example of crossed fleet:
        /// [*][][]
        /// [][*][]
        /// [][][*]
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns>true if validation successful, false if not</returns>
        private bool FleetHasNotCrossed(BattleFleet battleFleet)
        {
            bool fleetHasNotCrossed = false;
            //A Fleet has not crossed IF either x or y of each square position matches with the first square 
            Array.ForEach(battleFleet.fleet, fleet => fleetHasNotCrossed =
            (fleet.x != battleFleet.fleet[0].x && fleet.y != battleFleet.fleet[0].y) ? false : true);
            return fleetHasNotCrossed;
        }

        /// <summary>
        /// Check if the given fleet is atomic (All squares of the fleet are next to each other)
        /// Example of none atomic fleet:
        /// [*][][*]
        /// [][][]
        /// [][][]
        /// </summary>
        /// <param name="battleFleet"></param>
        /// <returns>true if validation successful, false if not</returns>
        private bool FleetIsAtomic(BattleFleet battleFleet)
        {
            for (int i = 0; i < battleFleet.fleet.Length; i++)
            {
                //Fleet is atomic if all squares of the fleet are in sequence
                if (i + 1 < battleFleet.fleet.Length) {
                    if (battleFleet.fleet[i].x == battleFleet.fleet[i + 1].x)
                    {
                        if (battleFleet.fleet[i].y == battleFleet.fleet[i + 1].y +  1 || battleFleet.fleet[i].y == battleFleet.fleet[i + 1].y - 1)
                        {
                            continue;
                        } else
                        {
                            return false;
                        }
                    }
                    else if (battleFleet.fleet[i].y == battleFleet.fleet[i + 1].y)
                    {
                        if (battleFleet.fleet[i].x == battleFleet.fleet[i + 1].x + 1 || battleFleet.fleet[i].x == battleFleet.fleet[i + 1].x - 1)
                        {
                            continue;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion private methods

    }
}
