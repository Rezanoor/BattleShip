﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.lib.Model
{
    public class Squar
    {
        public int x { get; set; }
        public int y { get; set; }
        public bool destroyed { get; set; } = false;
    }
}
