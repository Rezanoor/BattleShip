﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.lib.Model
{
    public class BattleFleet
    {
        public Squar[] fleet { get; set; }
        public FleetType type { get; set; }

    }

    public enum FleetType
    {
        ship = 1
    }

    /// <summary>
    /// This is the second version of battlefleet. 
    /// Using this has it's own pros and cons
    /// </summary>
    public class BattleFleet2
    {
        public Squar startPosition { get; set; }
        public int length { get; set; }
        public Direction direction { get; set; }
        public FleetType type { get; set; }

    }

    public enum Direction
    {
        down = 1,
        right = 2
        
    }
}
