﻿using BattleShip.lib.Model;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace BattleShip.Test
{
    public class InvalidFleetCozCrossedTest
    {
        Game _game;

        public InvalidFleetCozCrossedTest()
        {
            _game = new Game(10, 10);
        }

        [Theory]
        [InlineData(1, 9)]
        public void RunTest(int x, int y)
        {
            //Create board
            Assert.NotNull(_game);

            //Add Fleet
            Squar squarA1 = new Squar { x = 0, y = 1 };
            Squar squarA2 = new Squar { x = 0, y = 2 };
            Squar squarA3 = new Squar { x = 1, y = 3 };
            BattleFleet battleFleet = new BattleFleet { fleet = new Squar[] { squarA1, squarA2, squarA3 }, type = FleetType.ship };

            Assert.False(_game.AddFleet(battleFleet));
            
        }
    }
}
