using BattleShip.lib.Model;
using System;
using Xunit;

namespace BattleShip.Test
{
    public class BattleShipSimpleTest
    {

        Game _game;
        
        public BattleShipSimpleTest()
        {
            _game = new Game(10, 10);
        }

        [Theory]
        [InlineData(1, 9)]
        public void RunTest(int x, int y)
        {
            //Create board
            Assert.NotNull(_game);

            //Add Fleet
            Squar squar1 = new Squar { x = 1, y = 1 };
            Squar squar2 = new Squar { x = 1, y = 2 };
            Squar squar3 = new Squar { x = 1, y = 3 };
            BattleFleet battleFleet = new BattleFleet {fleet = new Squar[] { squar1, squar2, squar3}, type = FleetType.ship };
            Assert.True(_game.AddFleet(battleFleet));

            //Attach
            Assert.Equal(_game.Attack(x, y), 0);

            //Has player lost
            Assert.False(_game.HasPlayerLostYet());
        }

    }
}
